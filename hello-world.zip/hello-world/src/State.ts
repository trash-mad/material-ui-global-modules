namespace HelloWorld
{
    export enum ActionType
    {
        Increment = "increment-action"
    }

    const initialState = {
        value: 0
    }

    function Reducer(state = initialState, action:Redux.Action<ActionType>&any) 
    {
        state = Object.assign({},state);

        switch (action.type) 
        {
            case ActionType.Increment:
                state.value = state.value + 1;
                break;
        }
        return state;
    }

    export const Store = Redux.createStore(Reducer);
}