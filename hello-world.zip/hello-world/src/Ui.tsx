namespace HelloWorld
{
    function App()
    {
        return(
            <ReactRedux.Provider store={Store}>
                <MainPage/>
            </ReactRedux.Provider>
        );
    }

    export function Main()
    {
        if(!window.localStorage)
        {
            (window as any).localStorage = {
                getItem: function (str){},
                setItem: function(a,b){}
            }
        }

        ReactDOM.render(<App/>, document.getElementById('mount-point'));
    }
}