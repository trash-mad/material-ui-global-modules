
// <reference path="../classes/ItemParser.ts" />

namespace HelloWorld
{
    const {
        AppBar,
        MuiThemeProvider,
        Drawer,
        MenuItem,
        Tabs,
        Tab,
    } = MaterialUi;

    const {
        Card,
        CardHeader,
        CardMedia,
        CardTitle,
        CardText,
        CardActions,
        FlatButton
    } = MaterialUi;

    /*const {
        darkBaseTheme, 
        getMuiTheme
    } = MaterialUi.Styles;*/

    namespace Internal
    {
        export class MainPage extends React.Component<any,any>
        {
        
            constructor(props: any)
            {
                super(props);

                this.state = {
                    drawerOpen: false,
                    currentTab: 'first'
                };
            }

            toggleDrawer = () => this.setState({drawerOpen: !this.state.drawerOpen});

            handleChange = (tab) => {this.setState({currentTab: tab});};

            render()
            {
                return (          
                    <MuiThemeProvider /*muiTheme={getMuiTheme(darkBaseTheme)}*/>
                        <Drawer docked={false} open={this.state.drawerOpen} onRequestChange={this.toggleDrawer}>
                            <MenuItem onClick={this.props.toggleDialog}>Menu item</MenuItem>
                            <MenuItem onClick={this.props.toggleDialog}>Menu item</MenuItem>
                            <MenuItem onClick={this.props.toggleDialog}>Menu item</MenuItem>
                            <MenuItem onClick={this.props.toggleDialog}>Menu item</MenuItem>
                        </Drawer>
                        <AppBar title={"Hello world"} onLeftIconButtonClick={this.toggleDrawer}></AppBar>
                        <Tabs value={this.state.currentTab} onChange={this.handleChange}>
                            <Tab label="Вкладка 1" value={"first"}>
                                <FlatButton onClick={this.props.increment} label={this.props.value.toString()} />
                            </Tab>
                            <Tab label="Вкладка 2" value={"second"}>
                            </Tab>
                        </Tabs>
                    </MuiThemeProvider>
                );
            } 
        }
    }

    function mapStateToProps (state) {
        return {
            value: state.value
        }
    }

    function mapDispatchToProps(dispatch:Redux.Dispatch)
    {
        return {
            increment: () => { dispatch({type:ActionType.Increment}) }
        }
    }


    export const MainPage = ReactRedux.connect(mapStateToProps,mapDispatchToProps)(Internal.MainPage);
}